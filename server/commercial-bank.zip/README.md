# mTLS Certificate Bundle

This archive includes all credentials required for mutual TLS:

- commercial-bank-client.key    :: Private key for your client authentication
- commercial-bank-client.crt    :: Client certificate signed by root-ca.crt
- commercial-bank-server.key    :: Private key for your server TLS endpoint
- commercial-bank-server.crt    :: Server certificate signed by root-ca.crt
- root-ca.crt          :: Shared root certificate used to validate all other teams' certs
